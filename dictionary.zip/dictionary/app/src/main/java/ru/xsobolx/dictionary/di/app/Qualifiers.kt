package ru.xsobolx.dictionary.di.app

import java.lang.annotation.RetentionPolicy
import javax.inject.Qualifier

@Retention(AnnotationRetention.SOURCE)
@Qualifier
annotation class AppContext
