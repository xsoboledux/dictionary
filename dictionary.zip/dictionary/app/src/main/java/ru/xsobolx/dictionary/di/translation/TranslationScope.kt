package ru.xsobolx.dictionary.di.translation

import javax.inject.Scope

@Scope
@Retention(AnnotationRetention.SOURCE)
annotation class TranslationScope