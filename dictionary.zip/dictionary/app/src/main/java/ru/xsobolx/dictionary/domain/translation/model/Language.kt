package ru.xsobolx.dictionary.domain.translation.model

enum class Language(val lang: String) {
    EN("en"), DE("de"), ES("es"), RU("ru")
}