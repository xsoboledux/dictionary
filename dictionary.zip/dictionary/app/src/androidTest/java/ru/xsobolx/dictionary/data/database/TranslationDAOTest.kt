package ru.xsobolx.dictionary.data.database

import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import org.junit.Before
import org.junit.runner.RunWith
import ru.xsobolx.dictionary.data.db.base.AppDatabase
import ru.xsobolx.dictionary.data.db.translation.dao.TranslationDAO

@RunWith(AndroidJUnit4ClassRunner::class)
class TranslationDAOTest {
    private lateinit var translationDAO: TranslationDAO
    private lateinit var db: AppDatabase

    @Before
    fun setUp() {
        val context = ApplicationProvider.
    }
}
